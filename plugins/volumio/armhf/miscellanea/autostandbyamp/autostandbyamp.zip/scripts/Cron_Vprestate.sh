#!/bin/sh

echo "stop" > /data/plugins/miscellanea/autostandbyamp/scripts/VpreState
